aic=function(object,...){
  AIC=object$AIC
  return(AIC)
}

bic=function(object,...){
  BIC=object$BIC
  return(BIC)
}

ebic=function(object,...){
  EBIC=object$BIC
  return(EBIC)
}



